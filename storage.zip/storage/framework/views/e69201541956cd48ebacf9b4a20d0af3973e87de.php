<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>Anti Traffik Alert</title>
    <link
      rel="stylesheet"
      href="https://use.fontawesome.com/releases/v5.11.2/css/all.css"
    />
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
    />
   <link rel="stylesheet" href=<?php echo e(asset("css/bootstrap.min.css")); ?> /> 
    
    
    
    <link rel="stylesheet" href=<?php echo e(asset("css/mdb.min.css")); ?> /> 
    <link rel="stylesheet" href=<?php echo e(asset("css/style.css")); ?> /> 
   
  </head>
  <body>
    <div id="app">
        <main-component></main-component>
    </div>
    
    
    <script type="text/javascript" src=<?php echo e(asset("js/jquery.min.js")); ?>></script>

    <script type="text/javascript" src=<?php echo e(asset("js/mdb.min.js")); ?>></script> 
    <script type="text/javascript" src=<?php echo e(asset("js/popper.min.js")); ?>></script>
    <script type="text/javascript" src=<?php echo e(asset("js/bootstrap.min.js")); ?>></script>
    
    <script type="text/javascript" src=<?php echo e(asset("js/index.js")); ?>></script>

    <script src=<?php echo e(asset("js/app.js")); ?>></script>
  </body>
</html>
