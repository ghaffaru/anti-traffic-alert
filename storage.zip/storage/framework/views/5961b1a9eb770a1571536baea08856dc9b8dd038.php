<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        

    </div>
    <!-- Default to the left -->
    
</footer>