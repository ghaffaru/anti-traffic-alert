<template>
  <section id="aboutus" class="mb-5">
    <h2 class="h1-responsive font-weight-bold text-center mb-5 pt-5">About Anti Traffik Alert (ATA)</h2>
    <div class="row">
      <div
        class="d-flex justify-content-center align-items-center col-lg-10 col-md-12 col-sm-12 mx-auto w-responsive"
      >
        <div class="about">
          <p>
            <span class="text">A</span>nti-
            <span class="text">T</span>raffik
            <span class="text">A</span>lert (ATA) is a technology solution focused on ending human trafficking/modern
            slavery globally. We believe in the dream of every person and we believe no one should be
            abused in any form. We are committed to freeing victims of human trafficking by working with
            various law enforcement agencies and victim protection organizations globally.
          </p>
          <p></p>
          <p>
            <span class="text-orange hastage">#</span> Together we make this world a safer place.
          </p>
          <p>
            <span class="text-orange hastage">NB</span> You can send anonymous information on this portal.
          </p>
        </div>
      </div>
    </div>

    <div class="row">
      <div
        class="d-flex justify-content-center align-items-center col-lg-10 col-md-12 col-sm-12 mx-auto w-responsive"
      ></div>
    </div>
  </section>
</template>

<script>
export default {
  name: "AboutUs"
};
</script>

<style scoped>
#aboutus {
  line-height: 1.8em;
  font-size: 1em;
}
.hastage {
  color: orange !important;
  font-size: 1.5;
  font-weight: bolder;
}
.text {
  font-size: 2em;
  font-style: italic;
  color: orange;
}
</style>